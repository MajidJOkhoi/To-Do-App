const tasks = [];
let showAlert = false;

const addTask = () => {
  const newTask = document.getElementById('newTask').value.trim();
  const newDate = document.getElementById('newDate').value.trim();
  const lastDate = document.getElementById('lastDate').value.trim();

  if (newTask !== '' && newDate !== '' && lastDate !== '') {
    const timestamp = new Date().toLocaleString();
    tasks.push({ task: newTask, date: newDate, last: lastDate, timestamp: timestamp });
    renderTasks();
    document.getElementById('newTask').value = '';
    document.getElementById('newDate').value = '';
    document.getElementById('lastDate').value = '';
  }
};

const deleteTask = (index) => {
  tasks.splice(index, 1);
  renderTasks();
};

const renderTasks = () => {
  const taskList = document.getElementById('taskList');
  taskList.innerHTML = '';

  tasks.forEach((task, index) => {
    const li = document.createElement('li');
    li.innerHTML = `
      <p'> <strong>Add Task:  </strong>${task.task} <strong> Start Date:  </strong>  ${task.date}  <strong>Last Date:  </strong>${task.last} <strong>Timestamp:  </strong>${task.timestamp} <br> <br> <button class="edit-btn" onclick="editTask(${index})">Edit</button> <button class="delete-btn" onclick="deleteTask(${index})">Delete</button></p>
    `;
    li.style.fontSize = '20px'
    taskList.appendChild(li);
  });

  showAlertLogic();
};



const editTask = (index) => {
  const updatedTask = prompt('Enter updated task:', tasks[index].task);
  if (updatedTask !== null && updatedTask.trim() !== '') {
    tasks[index].task = updatedTask.trim();
    renderTasks();
  }
};

const showAlertLogic = () => {
  tasks.forEach((task) => {
    if (task.date === task.last) {
      showAlert = true;
      setTimeout(() => {
        showAlert = false;
        document.getElementById('alert').classList.add('hidden');
      }, 10000); // Hide alert after 10 seconds

      document.getElementById('alert').classList.remove('hidden');
      document.getElementById('alert').innerHTML = 'Task is due today! Please complete it.';
    }
  });
};

document.getElementById('addTask').addEventListener('click', addTask);

setInterval(() => {
  showAlertLogic();
}, 2000);

renderTasks();
